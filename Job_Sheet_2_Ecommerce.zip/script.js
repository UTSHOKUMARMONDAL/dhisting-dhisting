
var login=document.getElementById("loginForm");
if(login) login.onclick=function(){alert("Login form submitted successfully!");};

var register=document.getElementById("registerForm");
if(register) register.onclick=function(){alert("Registration submitted successfully!");};

var cart=document.getElementById("cartBtn");
if(cart) cart.onclick=function(){alert("Product added to cart!");};

var date=document.getElementById("dateTime");
if(date) date.innerHTML=new Date().toLocaleString();
