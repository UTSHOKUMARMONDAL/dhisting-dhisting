// Reservation
if(document.getElementById("reservationSubmit")){document.getElementById("reservationSubmit").onclick=function(){var form=document.getElementById("reservationForm");if(!form.checkValidity()){form.reportValidity();return;}alert("Your table reservation has been submitted successfully.");form.reset();};}
// Login
if(document.getElementById("loginSubmit")){document.getElementById("loginSubmit").onclick=function(){var form=document.getElementById("loginForm");if(!form.checkValidity()){form.reportValidity();return;}alert("Login submitted successfully.");form.reset();};}
// Signup
if(document.getElementById("signupSubmit")){document.getElementById("signupSubmit").onclick=function(){var form=document.getElementById("signupForm");if(!form.checkValidity()){form.reportValidity();return;}alert("Your account has been created successfully.");form.reset();};}
// Newsletter
if(document.getElementById("newsletterSubmit")){document.getElementById("newsletterSubmit").onclick=function(){var form=document.getElementById("newsletterForm");if(!form.checkValidity()){form.reportValidity();return;}alert("Thank you for subscribing!");form.reset();};}
// Current date and time
if(document.getElementById("dateTime")){document.getElementById("dateTime").innerHTML=new Date();}
