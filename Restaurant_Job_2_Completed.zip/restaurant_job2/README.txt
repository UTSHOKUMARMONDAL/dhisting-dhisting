Restaurant Job Sheet 2 - Food Haven
Pages: index.html, menu.html, dish-detail.html, reservation.html, signup.html, login.html
External CSS: CSS/style.css
External JS: JS/script.js
Framework: Bootstrap 5
jQuery is loaded on the Dish Detail page through the shared footer; CSS hover zoom is used for the image zoom section.
