// FAQ

if (document.getElementById("faq1")) {

    document.getElementById("faq1").onclick = function() {
        document.getElementById("answer1").classList.toggle("open");
    };

    document.getElementById("faq2").onclick = function() {
        document.getElementById("answer2").classList.toggle("open");
    };

    document.getElementById("faq3").onclick = function() {
        document.getElementById("answer3").classList.toggle("open");
    };

    document.getElementById("faq4").onclick = function() {
        document.getElementById("answer4").classList.toggle("open");
    };

    document.getElementById("faq5").onclick = function() {
        document.getElementById("answer5").classList.toggle("open");
    };

}




if (document.getElementById("clicked")) {

    document.getElementById("clicked").onclick = function() {

        var form = document.getElementById("contactForm");

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        alert("Thank you! Your message has been submitted successfully.");

        form.reset();
    };

}




if (document.getElementById("dateTime")) {
    document.getElementById("dateTime").innerHTML = new Date();
}

if (document.getElementById("dateTimeHero")) {
    document.getElementById("dateTimeHero").innerHTML = new Date();
}